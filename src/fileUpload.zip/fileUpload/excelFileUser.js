import React from "react";
import FileUpload from "./excelFileUpload";
const GetFile = () => {
  const classname = [];
  const propsData = {
    fileTypes: [], //"text/csv","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/pdf","text/plain"
    Size: "1",
    unit: "mb",
    multipleSelect: true, //if multiple select false ?drag and drop will not work.
    classname: classname,
    DragandDrop: true,
  };
  return (
    <>
      <FileUpload options={propsData} />
    </>
  );
};
export default GetFile;
